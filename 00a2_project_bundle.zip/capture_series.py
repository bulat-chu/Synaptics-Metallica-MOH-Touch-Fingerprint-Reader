#!/usr/bin/env python3
"""
capture_series.py - take a series of full 112x112 frames from a Synaptics 06cb:00a2 sensor.

What it does (same steps as probe_00a2.py stages 1-5, without the diagnostics):
  1. opens the sensor, replays the Windows driver's init sequence, reads the TLS flash,
     and opens the TLS session with the EXISTING pairing (needs --name/--serial of the paired PC);
  2. calibrates IN MEMORY ONLY (no flash write, no calibration file);
  3. for every finger and touch: arms the capture, waits for the finger, reads the whole
     frame (two reads of the sensor's result buffer) and saves it as <out>/frame_full-<finger>-<touch>.pgm.

A frame is saved only if it is complete (width*height pixels, error field 0).
Partial or truncated images are never written.

Setup (Arch): sudo pacman -S python-pyusb python-cryptography git
              git clone https://github.com/uunicorn/python-validity
Run:          sudo python3 capture_series.py --repo ./python-validity --name "<product name>" --serial "<serial>" --fingers 2 --touches 5
"""
import argparse, atexit, csv, logging, os, struct, sys, time
from binascii import hexlify, unhexlify

# 581-byte init blob that the Windows driver sends at the start of every session (from the USB capture)
INIT_BLOB_HEX = (
    "06020000017f157bcf4f0360ff4dae96e4721ee8834bf6ab6f2828da9ad2b3ff40ab7e5176c478dd2459747722fc914b"
    "8b98b22d5a9574f52c0e8b257b952e7ce12ed46ef77801481d698006fd09e5a9a8d7e9ca705a79549b984504778513b7"
    "2668f9a5b7f41dd5537460ced2c46ac9a70e345638ba7cb04f3829105f64bd2ddf5a0cb418ad350b022d2eace9fe2104"
    "2e402bc9524bd87208271849c199280ffed5a881a547074fcaf33a22aec694f028b9cf56818d9792066e3bbfc72d6930"
    "050d45c9a2edeba1abd07f3b40e3830ff31aa9dab715f59bb150686d5648808a9ff9e775f58f6c6e3910eb1a579bb206"
    "178545d54c5dd32a0d3e247e64d73afe84d701b42a8920ea02768734221260d083bebb39c176d129c01d1a0f13884971"
    "71402ba041afd925d71e76ce4905e44fa5fd528759a2c9f12895864b5aa394dc71a4a17161dd82197a10742fa5f3135c"
    "5e78820e36653fa3db535f57c71897242939d7da50f81070ce9ab81c61af6ac29a6c6c4a5df73ffd08542fb540e41793"
    "9ed117298051d27736c2faf1c5577a2133b6f60ea7484c692faae2a49c51c8e6f69af77774bad51a9adeea3109d3611d"
    "6a437cdc0c356e46a8f9a6d3054c5519c17c986e54f61f8329006ce184c275984799dbdf5512188fa8ff10aa2ddc25eb"
    "697ebdcb156509309ade5d7909a734bf35ec69e062cb941c2ea4af0958110da93bd2b5f17fc9b1ebdbd8020a3c36f22a"
    "68f707226cec716126d6a830219521669bd59fa0e4bd35db6ef0aa2999d1c0e7acf67e598696cd58cc4bdb1b7c037ee9"
    "a085f784c4"
)

def status_ok(rsp, what):
    if len(rsp) < 2 or struct.unpack('<H', rsp[:2])[0] != 0:
        raise RuntimeError('%s: unexpected reply %s' % (what, hexlify(rsp[:16]).decode()))
    return rsp

def parse_first_read(res):
    """Reply to '51 00 20 00 00': status(2) + length(4) + 12-byte header + first part of the pixels."""
    status_ok(res, 'frame read 1')
    n = struct.unpack('<L', res[2:6])[0]
    payload = res[6:6 + n]
    x, y, w1, w2, err = struct.unpack('<HHHHL', payload[:12])
    return (x, y, w1, w2, err), payload[12:]

def parse_next_read(res):
    """Reply to a following '51 <len>': status(2) + length(4) + more pixels (no header)."""
    status_ok(res, 'frame read 2')
    n = struct.unpack('<L', res[2:6])[0]
    return res[6:6 + n]

def save_pgm(path, pix, width, height):
    with open(path, 'wb') as f:
        f.write(b'P5\n%d %d\n255\n' % (width, height))
        f.write(pix)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', default='./python-validity')
    ap.add_argument('--name', required=True, help='product name of the PC the sensor is paired with')
    ap.add_argument('--serial', required=True, help='serial number of that PC')
    ap.add_argument('--fingers', type=int, default=2)
    ap.add_argument('--touches', type=int, default=5)
    ap.add_argument('--out', default='frames')
    ap.add_argument('--timeout', type=int, default=60, help='seconds to wait for a finger')
    ap.add_argument('--extra-read', type=int, default=0, metavar='N',
                    help='experiment: after the frame, also ask the result buffer for N more bytes (51 <N>) and save the raw reply '
                         '(read-only attempt; the Windows capture shows ~23104-byte replies after the frame)')
    ap.add_argument('--trace', action='store_true', help='log USB traffic (big log)')
    ap.add_argument('--no-reset', action='store_true')
    a = ap.parse_args()

    logging.basicConfig(filename='capture_series.log', level=logging.DEBUG, format='%(message)s')
    sys.path.insert(0, a.repo)
    from validitysensor.usb import usb
    from validitysensor.tls import tls
    usb.trace_enabled = a.trace
    tls.trace_enabled = False   # never log TLS secrets

    usb.open(0x06cb, 0x00a2)
    if not a.no_reset:
        def _reset():
            try:
                usb.dev.reset()
            except Exception as e:
                logging.debug('reset failed: %r', e)
        atexit.register(_reset)

    # --- session start: the sequence seen in the Windows capture ---
    for c in ('01', '19', '4302'):
        status_ok(usb.cmd(unhexlify(c)), c)
    status_ok(usb.cmd(unhexlify(INIT_BLOB_HEX.replace('\n', '').replace(' ', ''))), 'init blob')
    status_ok(usb.cmd(unhexlify('3e')), '3e')
    r = status_ok(usb.cmd(struct.pack('<BBBHLL', 0x40, 1, 1, 0, 0, 0x1000)), 'read TLS flash')
    size = struct.unpack('<xxLxx', r[:8])[0]
    flash = r[8:8 + size]
    tls.set_hwkey(a.name, a.serial)
    tls.parse_tls_flash(flash)          # fails here if name/serial do not match the pairing
    tls.open()
    print('TLS session open')

    # --- calibration in memory only ---
    from validitysensor.sensor import sensor, CaptureMode
    from validitysensor.sensor import get_prg_status2
    sensor.persist_clean_slate = lambda clean_slate: None
    sensor.save = lambda: None
    print('Do NOT touch the sensor. Calibrating (in memory, nothing is written)...')
    sensor.open()
    print('Calibration done.')

    def wait_int(deadline):
        while time.time() < deadline:
            try:
                return bytes(usb.dev.read(131, 1024, timeout=500))
            except Exception as e:
                if 'timeout' in str(e).lower() or getattr(e, 'errno', None) in (60, 110):
                    continue
                raise
        raise TimeoutError('no finger within %d s' % a.timeout)

    def capture_frame():
        cmd = sensor.build_cmd_02(CaptureMode.IDENTIFY)
        try:
            status_ok(tls.app(cmd), 'start capture')
            deadline = time.time() + a.timeout
            wait_int(deadline)                       # 00 ... start event
            while wait_int(deadline)[0] != 2:        # finger detected
                pass
            while True:                              # wait until the capture is complete
                b = wait_int(deadline + 10)
                if b[0] != 3:
                    raise RuntimeError('unexpected interrupt %s' % hexlify(b).decode())
                if b[2] & 4:
                    break
            hdr, pix = parse_first_read(get_prg_status2())
            x, y, w1, w2, err = hdr
            need = x * y
            pix = bytearray(pix)
            tries = 0
            while len(pix) < need and tries < 6:     # the result buffer is read sequentially
                pix += parse_next_read(tls.app(b'\x51' + struct.pack('<L', 12 + need)))
                tries += 1
            if err != 0 or x == 0 or y == 0 or len(pix) != need:
                raise RuntimeError('incomplete frame: %dx%d, %d of %d pixels, error field %d' % (x, y, len(pix), need, err))
            extra = None
            if a.extra_read:
                try:
                    extra = tls.app(b'\x51' + struct.pack('<L', a.extra_read))
                except Exception as e:
                    extra = 'error: %r' % (e,)
            return hdr, bytes(pix), extra
        finally:
            try:
                tls.app(unhexlify('04'))             # stop capture, as python-validity does
            except Exception as e:
                logging.debug('stop capture failed: %r', e)

    os.makedirs(a.out, exist_ok=True)
    index = os.path.join(a.out, 'index.csv')
    new_index = not os.path.exists(index)
    with open(index, 'a', newline='') as fi:
        w = csv.writer(fi)
        if new_index:
            w.writerow(['file', 'finger', 'touch', 'width', 'height', 'w1', 'w2', 'stddev', 'time'])
        for finger in range(1, a.fingers + 1):
            print('\n=== Finger %d of %d (use the same finger, centred, same pressure) ===' % (finger, a.fingers))
            touch = 1
            while touch <= a.touches:
                input('Finger %d, touch %d/%d: press Enter, then put the finger on the sensor... ' % (finger, touch, a.touches))
                try:
                    hdr, pix, extra = capture_frame()
                except Exception as e:
                    print('   capture failed (%s). Try again.' % e)
                    continue
                x, y, w1, w2, err = hdr
                mean = sum(pix) / len(pix)
                sd = (sum((v - mean) ** 2 for v in pix) / len(pix)) ** 0.5
                name = 'frame_full-%d-%d.pgm' % (finger, touch)
                path = os.path.join(a.out, name)
                if os.path.exists(path):
                    path = os.path.join(a.out, 'frame_full-%d-%d-%d.pgm' % (finger, touch, int(time.time())))
                save_pgm(path, pix, x, y)
                w.writerow([os.path.basename(path), finger, touch, x, y, w1, w2, '%.1f' % sd, time.strftime('%Y-%m-%d %H:%M:%S')])
                fi.flush()
                print('   saved %s (%dx%d, contrast %.0f)%s' % (path, x, y, sd, '  <- very flat, finger probably not touching' if sd < 25 else ''))
                if extra is not None:
                    if isinstance(extra, str):
                        print('   extra read: ' + extra)
                    else:
                        ep = os.path.join(a.out, 'extra_%d-%d.bin' % (finger, touch))
                        open(ep, 'wb').write(extra)
                        st = struct.unpack('<H', extra[:2])[0] if len(extra) >= 2 else None
                        print('   extra read: %d bytes, status %s, saved to %s, head %s' % (
                            len(extra), ('0x%04x' % st) if st is not None else '?', ep, hexlify(extra[:16]).decode()))
                touch += 1
                print('   lift the finger...')
                time.sleep(1.5)
    print('\nDone. Frames are in %s/' % a.out)

if __name__ == '__main__':
    main()
