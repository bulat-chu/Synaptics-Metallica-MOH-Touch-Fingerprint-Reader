#!/usr/bin/env python3
"""
Staged, step-by-step probe of a Synaptics 06cb:00a2 fingerprint sensor on Linux.
It replays the command sequence that the Windows driver sent in the USB capture
and decodes the answers, using the TLS code from python-validity.

  Stage 1: read-only queries      01, 19, 43 02
  Stage 2: + the init blob the Windows driver sent, 3e, and read of TLS flash
           (40 01 ...), compared with the dump taken from the capture
  Stage 3: + TLS handshake using the existing pairing (needs the name/serial of
           the PC the sensor is paired with), then queries 01, 75, 43 02 over TLS
  Stage 4: + read-only: factory bits (6f) and the header of flash partition 6.
           No calibration, no capture, no writes.
  Stage 5: + calibration in memory only (persisting switched off) and one capture
           with a finger. No flash writes.

Nothing here calls factory-reset, flash-write, erase or firmware upload.
The init blob in stage 2 is a command with an unknown effect: it is exactly
what the Windows driver sent at the start of every session in the capture.
Run stage by stage and stop if an answer looks wrong.

Setup (Arch): sudo pacman -S python-pyusb python-cryptography git
              git clone https://github.com/uunicorn/python-validity
Run:          sudo python3 probe_00a2.py --repo ./python-validity --stage 1
"""
import argparse, atexit, logging, struct, sys, hashlib
from binascii import hexlify, unhexlify

# 581-byte blob sent by the Windows driver (packet 63 of the capture)
INIT_BLOB_HEX = (
    "06020000017f157bcf4f0360ff4dae96e4721ee8834bf6ab6f2828da9ad2b3ff40ab7e5176c478dd2459747722fc914b"
    "8b98b22d5a9574f52c0e8b257b952e7ce12ed46ef77801481d698006fd09e5a9a8d7e9ca705a79549b984504778513b7"
    "2668f9a5b7f41dd5537460ced2c46ac9a70e345638ba7cb04f3829105f64bd2ddf5a0cb418ad350b022d2eace9fe2104"
    "2e402bc9524bd87208271849c199280ffed5a881a547074fcaf33a22aec694f028b9cf56818d9792066e3bbfc72d6930"
    "050d45c9a2edeba1abd07f3b40e3830ff31aa9dab715f59bb150686d5648808a9ff9e775f58f6c6e3910eb1a579bb206"
    "178545d54c5dd32a0d3e247e64d73afe84d701b42a8920ea02768734221260d083bebb39c176d129c01d1a0f13884971"
    "71402ba041afd925d71e76ce4905e44fa5fd528759a2c9f12895864b5aa394dc71a4a17161dd82197a10742fa5f3135c"
    "5e78820e36653fa3db535f57c71897242939d7da50f81070ce9ab81c61af6ac29a6c6c4a5df73ffd08542fb540e41793"
    "9ed117298051d27736c2faf1c5577a2133b6f60ea7484c692faae2a49c51c8e6f69af77774bad51a9adeea3109d3611d"
    "6a437cdc0c356e46a8f9a6d3054c5519c17c986e54f61f8329006ce184c275984799dbdf5512188fa8ff10aa2ddc25eb"
    "697ebdcb156509309ade5d7909a734bf35ec69e062cb941c2ea4af0958110da93bd2b5f17fc9b1ebdbd8020a3c36f22a"
    "68f707226cec716126d6a830219521669bd59fa0e4bd35db6ef0aa2999d1c0e7acf67e598696cd58cc4bdb1b7c037ee9"
    "a085f784c4"
)

def st(rsp):
    return struct.unpack('<H', rsp[:2])[0] if len(rsp) >= 2 else None

def show(label, rsp):
    print('%-28s status=%s len=%d  %s' % (label, ('0x%04x' % st(rsp)) if st(rsp) is not None else '?', len(rsp), hexlify(rsp[:48]).decode()))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', default='./python-validity', help='path to the python-validity checkout')
    ap.add_argument('--stage', type=int, default=1, choices=[1, 2, 3, 4, 5, 6])
    ap.add_argument('--name', help='stage 3: product name of the paired PC')
    ap.add_argument('--serial', help='stage 3: serial number of the paired PC')
    ap.add_argument('--expect-flash', default='tls_flash.bin', help='stage 2: dump from the capture to compare with')
    ap.add_argument('--log', default='probe_00a2.log')
    ap.add_argument('--no-reset', action='store_true', help='do not reset the USB device at exit')
    a = ap.parse_args()

    logging.basicConfig(filename=a.log, level=logging.DEBUG, format='%(message)s')
    sys.path.insert(0, a.repo)
    from validitysensor.usb import usb
    from validitysensor.tls import tls
    usb.trace_enabled = True
    tls.trace_enabled = False  # tls traces would log private keys

    usb.open(0x06cb, 0x00a2)
    print('opened 06cb:00a2')

    def _reset():
        # python-validity also resets the device at exit (Usb.close); this is
        # the software equivalent of re-plugging it, so the next run starts clean
        try:
            usb.dev.reset()
        except Exception as e:
            logging.debug('reset at exit failed: %r', e)
    if not a.no_reset:
        atexit.register(_reset)

    # ---- stage 1 ----
    r = usb.cmd(unhexlify('01')); show('01 (rom info)', r)
    if len(r) >= 18:
        ts, build, major, minor, prod, u1 = struct.unpack('<LLBBxBxxxB', r[2:18])
        print('   timestamp=%d build=%d major=%d minor=%d product=0x%02x u1=%d' % (ts, build, major, minor, prod, u1))
    show('19', usb.cmd(unhexlify('19')))
    r = usb.cmd(unhexlify('4302')); show('43 02 (fw info)', r)
    if a.stage == 1:
        print('stage 1 done, log: ' + a.log); return

    # ---- stage 2 ----
    show('init blob (581 bytes)', usb.cmd(unhexlify(INIT_BLOB_HEX.replace('\n', '').replace(' ', ''))))
    show('3e', usb.cmd(unhexlify('3e')))
    # read_flash(partition=1, addr=0, size=0x1000), same bytes as in the capture
    r = usb.cmd(struct.pack('<BBBHLL', 0x40, 1, 1, 0, 0, 0x1000))
    show('40 (read TLS flash)', r)
    size = struct.unpack('<xxLxx', r[:8])[0]
    flash = r[8:8+size]
    open('tls_flash_live.bin', 'wb').write(flash)
    try:
        exp = open(a.expect_flash, 'rb').read()
        print('flash equals dump from capture:', exp == flash)
    except OSError:
        print('no', a.expect_flash, 'to compare with; saved tls_flash_live.bin')
    if a.stage == 2:
        print('stage 2 done, log: ' + a.log); return

    # ---- stage 3 ----
    if not (a.name and a.serial):
        sys.exit('stage 3 needs --name and --serial')
    tls.set_hwkey(a.name, a.serial)
    tls.parse_tls_flash(flash)
    print('client key decrypted (pairing matches this name/serial)')
    tls.open()
    print('TLS handshake finished')
    show('01 over TLS', tls.cmd(unhexlify('01')))
    show('75 over TLS (sensor id)', tls.cmd(unhexlify('75')))
    show('43 02 over TLS', tls.cmd(unhexlify('4302')))
    if a.stage == 3:
        print('stage 3 done, log: ' + a.log); return

    # ---- stage 4: read-only, as in Sensor.open() of python-validity, minus calibration ----
    from validitysensor.sensor import get_factory_bits
    from validitysensor.flash import read_flash
    fb = get_factory_bits(0x0e00)
    print('factory bits (tag 0x0e00): subtags', sorted(fb.keys()))
    for k in sorted(fb):
        print('   subtag %d: %d bytes  %s' % (k, len(fb[k]), hexlify(fb[k][:32]).decode()))
    hdr = read_flash(6, 0, 0x44)
    print('flash partition 6, first 0x44 bytes (calibration "clean slate" header):')
    print('   ', hexlify(hdr).decode())
    print('   erased (all ff):', hdr == b'\xff' * 0x44)
    if a.stage == 4:
        print('stage 4 done, log: ' + a.log); return

    # ---- stage 5: calibrate IN MEMORY ONLY and capture one scan --------------------------
    # python-validity's Sensor.open() calibrates and then persists the result: erase + write of
    # flash partition 6 and a local calib file. Both are switched off here, so nothing is written.
    # Keep the finger OFF the sensor until the script asks for it.
    from validitysensor.sensor import sensor, CaptureMode
    sensor.persist_clean_slate = lambda clean_slate: print('   (skipped: would write flash partition 6)')
    sensor.save = lambda: print('   (skipped: would write local calibration file)')
    print('Keep the finger OFF the sensor. Calibrating in memory...')
    sensor.open()
    print('calibration done: type=0x%x lines_per_frame=%d bytes_per_line=%d calib_data=%d bytes' % (
        sensor.device_info.type, sensor.lines_per_frame, sensor.bytes_per_line, len(sensor.calib_data)))
    open('calib_data_ram.bin', 'wb').write(sensor.calib_data)
    input('Press Enter, then put a finger on the sensor (hold it ~1 s)... ')
    # Same sequence as Sensor.capture(), but every step is printed and the final status
    # reply is saved raw instead of being forced into the 12-byte layout python-validity expects
    # (that layout failed on this sensor: struct.error, buffer is not 12 bytes).
    import time
    from validitysensor.sensor import get_prg_status2
    cmd = sensor.build_cmd_02(CaptureMode.IDENTIFY)
    print('capture command: %d bytes' % len(cmd))
    t0 = time.time()

    def ev(label):
        b = usb.wait_int()
        print('  +%.2fs interrupt %s  (%s)' % (time.time() - t0, hexlify(b).decode(), label))
        return b
    try:
        show('02 (start capture)', tls.app(cmd))
        ev('start')
        while True:
            if ev('wait for finger')[0] == 2:
                break
        while True:
            b = ev('wait for completion')
            if b[0] != 3:
                raise Exception('unexpected interrupt %s' % hexlify(b).decode())
            if b[2] & 4:
                break
        # collect any further interrupts for a couple of seconds (the Windows capture shows more)
        t_end = time.time() + 2.5
        while time.time() < t_end:
            try:
                b = bytes(usb.dev.read(131, 1024, timeout=500))
                print('  +%.2fs interrupt %s  (after completion)' % (time.time() - t0, hexlify(b).decode()))
            except Exception:
                pass
        res = get_prg_status2()
        open('status2.bin', 'wb').write(res)
        paylen = struct.unpack('<L', res[2:6])[0] if len(res) >= 6 else None
        print('status2 reply: %d bytes total, payload length field = %s, saved to status2.bin' % (len(res), paylen))
        print('   head:', hexlify(res[:64]).decode())

        def save_pgm(path, pix, width=112):
            rows = len(pix) // width
            with open(path, 'wb') as f:
                f.write(b'P5\n%d %d\n255\n' % (width, rows))
                f.write(pix[:width * rows])
            print('   image %dx%d saved to %s' % (width, rows, path))
        save_pgm('frame_partial.pgm', res[6 + 12:])

        if a.stage >= 6:
            # Hypothesis from two examples (51 00 00 00 00 = status only, 51 00 20 00 00 = 8192 bytes back):
            # the 4 bytes after 51 are a little-endian read length. Full frame = 12-byte header + 112*112 pixels.
            want = 12 + 112 * 112
            full = tls.app(b'\x51' + struct.pack('<L', want))
            open('status_full.bin', 'wb').write(full)
            show('51 <len=%d>' % want, full)
            if len(full) >= 6:
                n = struct.unpack('<L', full[2:6])[0]
                print('   reply: %d bytes total, length field = %d (asked for %d)' % (len(full), n, want))
                # the buffer is read sequentially: the first read (51 00 20 00 00) returned 12 header bytes
                # plus 8180 pixels, this one returns the rest. Stitch them: 8180 + 4364 = 112 * 112 pixels.
                pix = res[6 + 12:6 + 8192] + full[6:6 + n]
                print('   stitched pixels: %d (expected %d)' % (len(pix), 112 * 112))
                save_pgm('frame_full.pgm', pix)
    finally:
        tls.app(unhexlify('04'))  # stop capture, as python-validity does
    print('stage 5 done, log: ' + a.log)

if __name__ == '__main__':
    main()
