#!/usr/bin/env python3
"""
nbis_eval.py - does a 112x112 frame from the 06cb:00a2 sensor work with NBIS matching?

Takes the frames saved by capture_series.py (frames/frame_full-<finger>-<touch>[-<time>].pgm),
prepares them (nothing is cropped by default, scales them up to about 500 dpi), runs NBIS
`mindtct` (minutiae) and `bozorth3` (matching) on every pair, and prints how well
"same finger" pairs are separated from "different finger" pairs.

The finger number is taken from the file name: frame_full-<finger>-...
By default it runs with normal brightness only (in the first real run, inverted brightness gave
identical numbers); --invert-too adds an inverted run. --scales 1.0,1.35,1.7,2.0 repeats the whole test
for several upscale factors and prints one summary table, because the number of minutiae NBIS finds
depends a lot on the scale.

Needs: Pillow (sudo pacman -S python-pillow) and the NBIS tools `mindtct` and `bozorth3` in PATH.
Run:   python3 nbis_eval.py --dir frames
"""
import argparse, csv, glob, itertools, os, re, subprocess, sys, tempfile
from statistics import median

try:
    from PIL import Image, ImageOps
except ImportError:
    sys.exit('Pillow is needed: sudo pacman -S python-pillow')


def prepare(src, dst_base, scale, crop_top, crop_bottom, invert, fmt):
    im = Image.open(src).convert('L')
    w, h = im.size
    im = im.crop((0, crop_top, w, h - crop_bottom))
    im = im.resize((round(im.width * scale), round(im.height * scale)), Image.BICUBIC)
    if invert:
        im = ImageOps.invert(im)
    path = dst_base + '.' + fmt
    if fmt == 'pgm':
        im.save(path)
    elif fmt == 'jpg':
        im.save(path, quality=100, dpi=(500, 500))   # baseline JPEG with a 500 dpi JFIF header
    else:
        im.save(path, dpi=(500, 500))
    return path


def run_mindtct(mindtct, img, oroot):
    p = subprocess.run([mindtct, img, oroot], capture_output=True, text=True)
    return p.returncode == 0 and os.path.exists(oroot + '.xyt'), (p.stderr or p.stdout).strip()


def bozorth(bozorth3, probe, gallery):
    p = subprocess.run([bozorth3, probe, gallery], capture_output=True, text=True)
    if p.returncode != 0 or not p.stdout.strip():
        raise RuntimeError('bozorth3 failed: ' + (p.stderr or p.stdout).strip())
    return int(p.stdout.split()[0])


def auc(gen, imp):
    return sum(1.0 if g > m else 0.5 if g == m else 0.0 for g in gen for m in imp) / (len(gen) * len(imp))


def evaluate(files, finger, args, invert, scale, work):
    tag = ('inverted' if invert else 'normal') + '_x%g' % scale
    print('\n==== brightness: %s, scale x%g ====' % ('inverted' if invert else 'normal', scale))
    xyt = {}
    fmt_order = [args.format] if args.format else ['pgm', 'jpg', 'png']
    for f in files:
        base = os.path.join(work, tag + '_' + os.path.splitext(os.path.basename(f))[0])
        ok = False
        for fmt in list(fmt_order):
            img = prepare(f, base, scale, args.crop_top, args.crop_bottom, invert, fmt)
            ok, msg = run_mindtct(args.mindtct, img, base)
            if ok:
                fmt_order = [fmt]          # this format works, keep using it
                break
        if not ok:
            sys.exit('mindtct failed on %s (tried %s): %s' % (f, ', '.join(fmt_order), msg))
        xyt[f] = base + '.xyt'
    counts = [sum(1 for _ in open(xyt[f])) for f in files]
    print('minutiae per frame: min %d, median %d, max %d' % (min(counts), median(counts), max(counts)))
    if min(counts) < 15:
        print('   note: some frames have very few minutiae (<15), matching will be unreliable')

    score = {}
    for a, b in itertools.combinations(files, 2):
        score[(a, b)] = score[(b, a)] = max(bozorth(args.bozorth3, xyt[a], xyt[b]), bozorth(args.bozorth3, xyt[b], xyt[a]))
    gen = [score[(a, b)] for a, b in itertools.combinations(files, 2) if finger[a] == finger[b]]
    imp = [score[(a, b)] for a, b in itertools.combinations(files, 2) if finger[a] != finger[b]]
    if not gen or not imp:
        sys.exit('need frames of at least two fingers with at least two touches each')

    def line(name, v):
        v = sorted(v)
        return '%-16s n=%3d  min %3d  median %5.1f  p75 %3d  max %3d' % (name, len(v), v[0], median(v), v[int(0.75 * (len(v) - 1))], v[-1])
    print(line('same finger', gen))
    print(line('different finger', imp))
    print('AUC (same-finger pair scores higher than different-finger pair): %.3f' % auc(gen, imp))
    thr = args.threshold
    print('pairs with score >= %d: same finger %d of %d, different finger %d of %d' % (
        thr, sum(g >= thr for g in gen), len(gen), sum(m >= thr for m in imp), len(imp)))
    print('score threshold -> same-finger pairs accepted / different-finger pairs accepted (false accepts)')
    for t in (1, 5, 10, 15, 20, 25, 30, 40):
        ga = sum(g >= t for g in gen); ia = sum(m >= t for m in imp)
        print('   >= %2d: %5.1f%% (%d/%d)   %5.2f%% (%d/%d)' % (t, 100.0 * ga / len(gen), ga, len(gen), 100.0 * ia / len(imp), ia, len(imp)))
    above = sum(g > max(imp) for g in gen)
    print('same-finger pairs above the best different-finger pair: %d of %d' % (above, len(gen)))

    # leave-one-out identification: a frame is compared with all OTHER frames of each finger,
    # the best score per finger decides; all-zero or tied results count as undecided
    fingers = sorted(set(finger.values()))
    right = wrong = undecided = 0
    for a in files:
        best = {k: max([score[(a, b)] for b in files if b != a and finger[b] == k] or [0]) for k in fingers}
        top = max(best.values())
        winners = [k for k in fingers if best[k] == top]
        if top == 0 or len(winners) > 1:
            undecided += 1
        elif winners[0] == finger[a]:
            right += 1
        else:
            wrong += 1
    print('identification against the other touches: correct %d, wrong %d, undecided (all scores 0 or tie) %d, of %d frames' % (right, wrong, undecided, len(files)))

    # verification as it would happen in use: a probe touch is compared with the other touches of ONE finger
    # and accepted if the best of those scores reaches the threshold
    best_by = {(a, k): max([score[(a, b)] for b in files if b != a and finger[b] == k] or [0]) for a in files for k in fingers}
    gen_att = [best_by[(a, finger[a])] for a in files]
    imp_att = [best_by[(a, k)] for a in files for k in fingers if k != finger[a]]
    print('verification against the other touches of a finger (accepted if the best score reaches the threshold):')
    print('   threshold   same finger accepted   different finger accepted')
    for t in (1, 5, 10, 15, 20, 25, 30, 40):
        ga = sum(g >= t for g in gen_att); ia = sum(m >= t for m in imp_att)
        print('   >= %2d       %5.1f%% (%2d/%d)       %5.2f%% (%d/%d)' % (t, 100.0 * ga / len(gen_att), ga, len(gen_att), 100.0 * ia / len(imp_att), ia, len(imp_att)))

    out = os.path.join(args.dir, 'nbis_scores_%s.csv' % tag)
    with open(out, 'w', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['frame_a', 'frame_b', 'same_finger', 'score'])
        for a, b in itertools.combinations(files, 2):
            w.writerow([os.path.basename(a), os.path.basename(b), int(finger[a] == finger[b]), score[(a, b)]])
    print('all pair scores saved to', out)
    return dict(mode=tag, minutiae=median(counts), gen_nonzero=sum(g > 0 for g in gen), gen_total=len(gen),
                imp_nonzero=sum(m > 0 for m in imp), imp_total=len(imp), max_gen=max(gen), auc=auc(gen, imp),
                right=right, wrong=wrong, undecided=undecided, n=len(files))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', default='frames')
    ap.add_argument('--scale', type=float, default=1.35, help='upscale factor (sensor is roughly 340-410 dpi, NBIS wants 500)')
    ap.add_argument('--scales', help='comma-separated list of scale factors to compare, e.g. 1.0,1.35,1.7,2.0')
    ap.add_argument('--invert-too', action='store_true', help='also run with inverted brightness')
    ap.add_argument('--crop-top', type=int, default=0, help='rows to cut from the top (default 0: nothing is cut)')
    ap.add_argument('--crop-bottom', type=int, default=0, help='rows to cut from the bottom (default 0)')
    ap.add_argument('--threshold', type=int, default=40, help='score used for the "accepted" count (libfprint default is, as far as I remember, 40: please check)')
    ap.add_argument('--format', choices=['pgm', 'jpg', 'png'], help='input format for mindtct (default: try pgm, jpg, png)')
    ap.add_argument('--mindtct', default='mindtct')
    ap.add_argument('--bozorth3', default='bozorth3')
    args = ap.parse_args()

    files = sorted(glob.glob(os.path.join(args.dir, 'frame_full-*.pgm')))
    if not files:
        files = sorted(glob.glob(os.path.join(args.dir, '**', 'frame_full-*.pgm'), recursive=True))
    if not files:
        sys.exit('No frame_full-*.pgm files found in %s (searched recursively).\n'
                 'Check the path: ls <dir> | head, or pass the folder with --dir <path>.' % os.path.abspath(args.dir))
    finger = {}
    for f in files:
        m = re.match(r'frame_full-(\d+)-', os.path.basename(f))
        if m:
            finger[f] = int(m.group(1))
    files = [f for f in files if f in finger]
    if len(set(finger.values())) < 2:
        sys.exit('Need frames of at least two fingers named frame_full-<finger>-<touch>.pgm, found: %s' % sorted(set(finger.values())))
    print('%d frames, fingers: %s' % (len(files), {k: sum(1 for f in files if finger[f] == k) for k in sorted(set(finger.values()))}))

    scales = [float(x) for x in args.scales.split(',')] if args.scales else [args.scale]
    rows = []
    with tempfile.TemporaryDirectory() as work:
        for scale in scales:
            for invert in ([False, True] if args.invert_too else [False]):
                rows.append(evaluate(files, finger, args, invert, scale, work))
    if len(rows) > 1:
        print('\n==== summary ====')
        print('%-18s %9s %14s %14s %8s %6s %22s' % ('run', 'minutiae', 'same>0', 'diff>0', 'max', 'AUC', 'ident ok/wrong/undec'))
        for r in rows:
            print('%-18s %9.0f %7d of %-4d %7d of %-4d %6d %6.3f %10d/%d/%d' % (
                r['mode'], r['minutiae'], r['gen_nonzero'], r['gen_total'], r['imp_nonzero'], r['imp_total'],
                r['max_gen'], r['auc'], r['right'], r['wrong'], r['undecided']))


if __name__ == '__main__':
    main()
